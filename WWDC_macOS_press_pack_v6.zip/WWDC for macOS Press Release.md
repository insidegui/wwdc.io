# WWDC for macOS Version 6
**Price:** Free (open-source)
**OS Support:** 10.12.2 (Sierra) and later
**Website:** https://wwdc.io

Today, the latest version of the unofficial WWDC app for macOS has been released, and is available to download now from https://wwdc.io . It allows users to both livestream ongoing WWDC sessions and watch a library of past sessions, and it is our goal to offer developers and Apple fans alike the best Keynote and Platforms State of the Union livestreaming experience available on macOS.

The open source app is developed by a small core team located throughout Brazil, the UK, and Spain, and was created by Guilherme Rambo, the “firmware spelunker” who last year discovered a glyph of the iPhone X in HomePod software over a month prior to the phone’s official announcement.

Previously, the app has received high praise from the community, including developers such as Marco Arment, Craig Hockenberry and Steve Troughton-Smith, and was named one of MacStories’ “Must-Have macOS apps of 2017”.

Following a ground-up redesign last year, the latest version offers a host of refinements and new features. Notably:

- **iCloud Syncing (*Beta*):** Users’ favourite sessions, video annotations, and playback information synchronises across all of their iCloud devices, allowing them to easily pick up where they left off or leave notes to pick up on when they're back at their work machine.

- **Touch Bar Support:** The app now has Touch Bar support for scrubbing through videos, adding bookmarks, and toggling picture-in-picture mode.

- **Calendar Integration:** Users can now easily add sessions to their macOS calendars at the click of a button, allowing users to plan their WWDC right from their Mac, whether attending or watching from home. Similarly, appointment-only sessions now allow users to go straight to the request form, and supported sessions now have links to directions.

- **Related Sessions:** The app now highlights related videos and labs for a given session. Users attending the conference can find a related hands-on lab and schedule it in their calendar in two clicks, and users watching from home or throughout the rest of the year can easily find follow-on videos to further their skills in the area.

With a range of further features planned soon, including curated playlists, shared bookmarks, and AirPlay support.

-----

WWDC for macOS allows both attendees and non-attendees to Apple’s Worldwide Developer Conference, starting next week in San Jose, to access live-streams, videos, and session information during the conference and as a year-round developer resource. It complements Apple’s official WWDC app for iOS, allowing developers, hobbyists and Apple fans alike to engage with the conference through a clean, simple and native UI on the device they already use for development. It also supports playback on both Chromecast devices and in picture-in-picture mode, crucial features for teams who plan to watch the keynote or sessions together, or those who wish to watch the conference alongside their usual work.
